# POMDP model comparison reproduction package

Contents:

- `harness/incident_server.py`: hidden-state simulator and programmatic scoring.
- `harness/run_incident_eval.py`: prompts, controlled Codex invocation, and experiment runner.
- `harness/analyze_results.py`: feature extraction, Wilson intervals, Fisher tests, and paired exact tests.
- `results/*.trace.json`: all 72 primary environment traces (replicates 1–3).
- `results/*.final.txt`: model final messages. There are 71 because `glm__explicit__db_pool__r1` timed out before producing a final message; its trace is present.
- `results/combined_results.json` and `results/trajectory_features.csv`: derived data.
- `gpt56_glm53_pomdp_final_report.html`: final Chinese technical report with embedded charts, tables, conclusions, and source metadata.
- `report_artifact.json`: canonical structured source used to build the portable HTML report.
- `gpt56_glm53_pomdp_report_zh.md`: earlier Chinese analysis draft, retained for comparison.

The raw Codex JSONL streams are intentionally excluded because a model can inspect the ephemeral client configuration during a run. The trace files contain every scored environment action and observation needed for the reported behavioral analysis, without packaging transient bearer credentials.

From the extracted package root, rerun all 72 trajectories with:

```powershell
python harness/run_incident_eval.py --conditions open,explicit,procedural --models gpt,glm --replicates 3 --replicate-start 1 --workers 4 --timeout 900
python harness/analyze_results.py
```

The runner expects the same model identifiers used in the original test: `gpt-5.6-sol` and `custom/z-ai/glm-5.3`.

The final HTML report is self-contained. Top-level copies of the reviewed JSON and CSV are included so its data-source links resolve after extraction; the harness and 72 traces are contained in this package directly.
